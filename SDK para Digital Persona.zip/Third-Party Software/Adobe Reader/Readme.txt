   -------------------------------------------------------------
		        DigitalPersona

                  Documentation Readme File

   -------------------------------------------------------------   

        (c) DigitalPersona, Inc., 2009. All rights reserved.

		
Adobe(r) Reader(r) 7 or later is needed to view or print the PDF documents contained in this CD. 

The Adobe Reader installation files are provided in the "Adobe Reader Installation" folder on this CD.

To install Adobe Reader, run the executable module located in the "Adobe Reader Installation" folder.

Adobe and Reader are either registered trademarks or trademarks of Adobe Systems Incorporated in the United States and/or other countries.